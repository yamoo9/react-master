import React from 'react'
import ReactDOM from 'react-dom'
import './index.css'

// import App from './App'
import AppForm from './layout/AppForm'

ReactDOM.render(<AppForm />, document.getElementById('root'))
