// jest-dom은 DOM 노드에 대한 어설션을 위한 사용자 지정 jest 매처를 추가합니다.
// 다음과 같은 작업을 수행 할 수 있습니다.
// expect (element).toHaveTextContent(/react/i)
// 자세히 알아보기 : https://github.com/testing-library/jest-dom
import '@testing-library/jest-dom/extend-expect';
