export * as pokemon from './pokemon'
