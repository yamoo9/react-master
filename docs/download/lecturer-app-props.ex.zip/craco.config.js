const sassSourcemapsPlugin = require('./config/plugins/craco-sass-sourcemap')

module.exports = {
	plugins: [
		{ plugin: sassSourcemapsPlugin },
	],
}
