module.exports = {
	plugins: [
		'babel-plugin-styled-components',
	],
}
