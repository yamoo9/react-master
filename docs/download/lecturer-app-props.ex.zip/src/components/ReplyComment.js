import React, { Component } from 'react'

export default class ReplyComment extends Component {
	render() {
		return <div className="reply-comment">{/* ... */}</div>
	}
}
