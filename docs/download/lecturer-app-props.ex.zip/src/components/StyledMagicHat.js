import React from 'react'
import styled, { keyframes } from 'styled-components'
import classNames from 'classnames'

const MagicHat = ({ className }) => {
	const classes = classNames('magic-hat', className)
	return (
		<div className={classes}>
			<span role="img" aria-label="마법 모자">
				🎩
			</span>
		</div>
	)
}

const Ottogi = keyframes`
  0% { transform: translateY(0) }
  25% { transform: translateY(-20px) rotate(20deg) }
  50% { transform: translateY(10px) }
  75% { transform: translateY(-15px) rotate(-20deg) }
  100% { transform: translateY(0) }
`

const StyledMagicHat = styled(MagicHat)`
  margin-top: 100px;
  font-size: 100px;
  text-align: center;
  span {
    display: block;
    transform: rotate(23deg);
    animation: ${Ottogi} 3s infinite cubic-bezier(0.35, 0.29, 0.4, 0.8);
  }
`

export default StyledMagicHat
