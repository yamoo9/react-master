import React from 'react'
import ReactDOM from 'react-dom'
import Lecturers from './Lecturers'
import { FEML_lecturers as lecturers } from 'App'

let tester

beforeEach(() => {
	tester = document.createElement('div')
})

afterEach(() => {
	ReactDOM.unmountComponentAtNode(tester)
})

const render = (props) => {
	ReactDOM.render(<Lecturers instructor={props.lecturers} />, tester)
}

it('Front-End Masters League 강사진 중 첫번째 강사의 이름', () => {
	render({ lecturers })
	const firstLecturerLink = tester.querySelector('.lecturer a')
	const href = firstLecturerLink.getAttribute('href')
	expect(href).toEqual('https://facebook.com/seulbinim')
})
