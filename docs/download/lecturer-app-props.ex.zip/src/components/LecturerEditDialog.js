import React, { Component } from 'react'
import styled from 'styled-components'
import classNames from 'classnames/bind'
import styles from './LecturerEditDialog.module.css'

import InputControl from './ui/InputControl'

const cx = classNames.bind(styles)

const ButtonGroup = styled.div.attrs((props) => ({
	role: 'group',
	className: 'button-group',
}))`
	display: flex;
	justify-content: flex-end;
	margin-right: -3px;
`

class LecturerEditDialog extends Component {
	state = {
		name: '',
		facebook: '',
		image: '',
		module: '',
	}

	_previousLecturer = null

	_updateState = (lecturer) => {
		if (lecturer !== this._previousLecturer) {
			this.setState({ ...lecturer })
			this._previousLecturer = lecturer
		}
	}

	shouldComponentUpdate(nextProps) {
		this._updateState(nextProps.editingLecturer)
		return true
	}

	handleInput = (e) => {
		const { id, value } = e.target
		this.setState({
			[id]: value,
		})
	}

	render() {
		const {
			editingLecturer,
			editLecturer,
			hideDialog,
			visibleClass,
		} = this.props

		const { name, module, facebook, image } = this.state

		const classes = cx('lecturer-edit-dialog', visibleClass)

		return (
			<div role="dialog" className={classes} aria-labelledby="dialog-headline">
				<div className="container panel">
					<h2 id="dialog-headline">강사 정보 수정</h2>
					{!editingLecturer ? (
						<p>수정 할 강사 정보가 없습니다.</p>
					) : (
						<form>
							<InputControl
								id="name"
								label="이름"
								value={name}
								onChange={this.handleInput}
							/>
							<InputControl
								id="module"
								label="모듈"
								value={module}
								onChange={this.handleInput}
							/>
							<InputControl
								id="facebook"
								label="SNS"
								value={facebook}
								onChange={this.handleInput}
							/>
							<InputControl
								id="image"
								label="이미지"
								value={image}
								onChange={this.handleInput}
							/>
							<ButtonGroup>
								<button
									type="submit"
									className="button is-filled"
									onClick={(e) => {
										e.preventDefault()
										editLecturer(editingLecturer.id, { ...this.state })
										hideDialog()
									}}
								>
									저장
								</button>
								<button
									type="reset"
									className="button theme-dark"
									onClick={() => {
										hideDialog()
									}}
								>
									취소
								</button>
							</ButtonGroup>
						</form>
					)}
				</div>
			</div>
		)
	}
}

export default LecturerEditDialog
