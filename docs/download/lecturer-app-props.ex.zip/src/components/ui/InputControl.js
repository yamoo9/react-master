import React from 'react'
import { string, func } from 'prop-types'

const InputControl = ({ type = 'text', id, label, value, onChange }) => (
	<div className="form-control">
		<label className="label" htmlFor={id}>
			{label}
		</label>
		<input
			type={type}
			id={id}
			className="input"
			value={value}
			onChange={onChange}
		/>
	</div>
)

InputControl.propTypes = {
	type: string,
	id: string.isRequired,
	label: string.isRequired,
	value: string.isRequired,
	onChange: func,
}

InputControl.defaultProps = {
	type: 'text',
}

export default InputControl
