import React from 'react'
import { string, func } from 'prop-types'
import classNames from 'classnames'

const ButtonControl = ({ type, children, className, onClick }) => {
	const classes = classNames('button', className)

	return (
		<button type={type || 'reset'} className={classes} onClick={onClick}>
			{children}
		</button>
	)
}

ButtonControl.propTypes = {
	type: string,
	onClick: func,
}

export default ButtonControl
