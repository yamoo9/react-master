import React from 'react'
import styled from 'styled-components'

const Button = styled.button`
	cursor: pointer;
	border: 2px solid rgba(255, 255, 255, 0.6);
	border-radius: 3px;
	margin-left: 3px;
	margin-right: 3px;
	padding: 0.6em 0.9em;
	background: transparent;
	color: #fff;
	font-size: 0.8rem;
	font-weight: 700;
	transition: all 0.25s ease-out;

	:hover,
	:focus {
		border-color: #fff;
	}

	&.is-filled {
		border-color: rgba(70, 37, 233, 0);
		background: rgba(255, 255, 255, 0.9);
		color: #282cf0;
	}
	&.is-filled:hover,
	&.is-filled:focus {
		color: rgba(255, 255, 255, 0.9);
		background: none;
		border: 2px solid currentColor;
	}
`

function Lecturer({ lecturer, removeLecturer, showDialog }){
	return (
		<li className="lecturer">
			<a href={lecturer.facebook} target="_blank" rel="noreferrer noopener">
				<figure className="lecturer-info">
					<img
						src={lecturer.image}
						alt=""
						width="50"
						height="50"
						className="lecturer-photo"
					/>
					<figcaption>
						{lecturer.module} 모듈을 담당 할 {lecturer.name} 강사 Facebook 바로가기
					</figcaption>
				</figure>
			</a>
			<div role="group" className="button-group">
				<Button type="button" onClick={() => showDialog(lecturer.id)}>
					수정
				</Button>
				<Button type="button" onClick={() => removeLecturer(lecturer.id)}>
					제거
				</Button>
			</div>
		</li>
	)
}

export default Lecturer
