// import { createStore } from 'redux'
import { newsReducer } from './reducers'

// createStore(reducer) => store {}
// store { getState, subscribe, dispatch }

const createStore = (reducer) => {
	let state // 외부에서 접근 불가능한 데이터

	let listeners = [] // 등록된(구독된) 리스너(함수) 보관하는 리스트(배열)

	// 데이터 반환 메서드
	const getState = () => state

	// 구독(업데이트 실행 함수 연결) 메서드
	const subscribe = (listener) => {
		listeners.push(listener)
		// 구독 취소(업데이트 연결 함수 제거) 함수 반환
		return (removeListener) => {
			listeners = listeners.filter((listener) => listener !== removeListener)
		}
	}

	// 디스패치(알림, 업데이트 요청) 메서드
	const dispatch = (action) => {
		// 1. state 업데이트
		state = reducer(state, action)
		// 2. listeners의 모든 listener를 실행
		listeners.forEach((listener) => listener())
	}

	// store 객체 내보내기
	return {
		getState,
		subscribe,
		dispatch,
	}
}

export default createStore(newsReducer)
