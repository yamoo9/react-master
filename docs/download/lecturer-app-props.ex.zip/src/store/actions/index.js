import { CHANGE_NEWS_TITLE } from './actionTypes'

export const changeNewsTitleAction = {
	type: CHANGE_NEWS_TITLE,
	payload: '행복한 뉴스',
}
