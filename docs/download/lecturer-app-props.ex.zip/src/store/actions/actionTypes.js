// newsReducer
export const CHANGE_NEWS_TITLE = 'change_news_title'

// todosReducer
export const ADD_TODO = 'ADD_TODO'
export const REMOVE_TODO = 'REMOVE_TODO'
export const RESET_TODO = 'RESET_TODO'
export const REPLACE_TODO = 'REPLACE_TODO'
