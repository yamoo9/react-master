import {
	ADD_TODO,
	REMOVE_TODO,
	RESET_TODO,
	REPLACE_TODO,
} from '../actions/actionTypes'

export const initialState = [
	'Redux 라이브러리 설치',
	'Redux 아키텍처 이해',
]

export const todosReducer = (state = initialState, { type, todo }) => {
	switch (type) {
		case ADD_TODO:
			state = [
				...state,
				todo,
			]
			break
		case REMOVE_TODO:
			state = state.filter((item) => item !== todo)
			break
		case RESET_TODO:
			state = initialState
			break
		case REPLACE_TODO:
			state = state.map((item) => {
				if (item === todo.item) {
					return todo.replaceItem
				}
				return item
			})
			break
		default:
			console.warn('일치하는 액션 타입이 존재하지 않습니다. 확인 후 다시 시도해보세요.')
	}
	return state
}
