import { CHANGE_NEWS_TITLE } from '../actions/actionTypes'

const initialNews = '공정하고 정의로운 뉴스'

export const newsReducer = (state = initialNews, action) => {
	switch (action.type) {
		case CHANGE_NEWS_TITLE:
			state = action.payload
			break
		default:
	}
	// ...
	return state
}
