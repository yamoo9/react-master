import React from 'react'
import styled from 'styled-components'
import { ReactComponent as Logo } from 'assets/logo-feml.svg'

const AppLogo = styled(Logo).attrs(({ size, spaceright }) => ({
	title: 'Front End 마스터스 리그 로고',
	id: 'SVG-LOGO',
	className: 'svg-logo',
	size: size || null,
	spaceright: spaceright || null,
}))`
	width: ${(props) => props.size};
	height: ${(props) => props.size};
	margin-right: ${(props) => props.spaceright};
`

const Link = styled('a')`
	color: ${({ color }) => color || '#fff'};
	text-decoration: none;
`

const LinkText = styled('span')`
	display: inline-flex;
	justify-content: center;
	align-items: center;
	width: 2.3rem;
	height: 2.3rem;
	margin-left: 10px;
	border-radius: ${({ rounded }) => (rounded ? '50%' : null)};
  padding-top: 2px;
  padding-left: 1px;
  padding-right: 1px;
	vertical-align: 1px;
	background: #fff;
	color: #3225e4;
`

const AppHeader = ({ lecturers }) => {
	return (
		<header className="App-header">
			<h1>
				<Link
					href="https://yamoo9.github.io"
					lang="en"
					target="_blank"
					rel="noopener noreferrer"
				>
					<AppLogo size="1.5rem" spaceright="10px" />
					Front-End Masters League
				</Link>{' '}
				강사진
				<LinkText rounded>{lecturers.length}</LinkText>
			</h1>
		</header>
	)
}

export default AppHeader
