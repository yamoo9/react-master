import React from 'react'
import './AppSplash.css'
import { ReactComponent as Logo } from 'assets/logo-feml.svg'

const AppSplash = () => {
	return (
		<div className="app-splash" role="main">
			<h1 className="a11y-hidden">앱을 준비 중...</h1>
			{/* <img src={logo} alt="" className="app-logo" /> */}
			<Logo className="app-logo" />
		</div>
	)
}

export default AppSplash
