import React, {useState, useEffect} from 'react'

export default function ReactHookExample(){
  
  const [headline] = useState({
    content: 'React Hook',
    lang: 'en'
  })

  const [image, setImage] = useState({
    src: 'http://pngimg.com/uploads/fish_hook/fish_hook_PNG62.png',
    alt: 'Hook'
  })

  const changeImagePath = (path) => {
    setImage({
      src: path,
      alt: 'Pandent'
    })
  }

  useEffect(()=> {
    console.log('update component')
  })

	return (
		<div className="app container">
			<h1 lang={headline.lang}>{headline.content}</h1>
			<p>React 훅(Hook)은 라이프 사이클 훅(Life Cycle Hook)과 다릅니다.</p>
			<img
				src={image.src}
				width="180"
				height="180"
				alt={image.alt}
				style={{ marginTop: 20, width: 180, height: 'auto' }}
			/>
      <div style={{marginTop: 30}}>
        <button type="button" onClick={() => changeImagePath('http://pngimg.com/uploads/jewelry/jewelry_PNG6739.png')}>이미지 교체</button>
      </div>
		</div>
	)
}