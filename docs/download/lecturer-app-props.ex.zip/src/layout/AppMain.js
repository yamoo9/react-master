import React, { Component } from 'react'
import Lecturers from 'components/Lecturers'
import styled from 'styled-components'

const Figure = styled.figure`
	margin: 0;
	img {
		width: 100%;
		height: auto;
	}
`

class AppMain extends Component {
	render() {
		const {
			lecturers,
			showDialog,
			hideDialog,
			removeLecturer,
			editLecturer,
		} = this.props

		const oopsImg =
			'https://thumbs.gfycat.com/AnguishedWindingIndusriverdolphin-size_restricted.gif'

		return (
			<main className="app-main">
				<h1 className="a11y-hidden">앱 메인 콘텐츠</h1>
				{lecturers.length === 0 ? (
					<Figure className="oops">
						<img src={oopsImg} alt="" />
						<figcaption lang="en">ANYBODY!</figcaption>
					</Figure>
				) : (
					<Lecturers
						lecturers={lecturers}
						showDialog={showDialog}
						hideDialog={hideDialog}
						removeLecturer={removeLecturer}
						editLecturer={editLecturer}
					/>
				)}
			</main>
		)
	}
}

export default AppMain
