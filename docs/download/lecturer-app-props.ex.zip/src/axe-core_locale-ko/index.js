import axeCore from 'axe-core'
import ko from './ko.json'

axeCore.configure({ locale: ko })
