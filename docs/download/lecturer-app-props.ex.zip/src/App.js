import React, { useState } from 'react'
import AppHeader from 'layout/AppHeader'

import AppMain from 'layout/AppMain'
import LecturerEditDialog from 'components/LecturerEditDialog'

export const FEML_lecturers = [
	{
		id: 'lecturer-az01871',
		name: '김데레사',
		module: 'A',
		facebook: 'https://facebook.com/seulbinim',
		image: 'https://yamoo9.github.io/images/photo-deresa@2x.png',
	},
	{
		id: 'lecturer-az01872',
		name: '야무',
		module: 'B,C',
		facebook: 'https://facebook.com/yamoo9',
		image: 'https://yamoo9.github.io/images/photo-yamoo9@2x.png',
	},
]

function App(){
	const [
		lecturers,
		setLecturers,
	] = useState(FEML_lecturers)
	const [
		isVisibleDialog,
		setVisibleDialog,
	] = useState(false)
	const [
		editingLecturer,
		setEditingLecturer,
	] = useState(null)

	const removeLecturer = (removeId) => {
		setLecturers(lecturers.filter((lecturer) => lecturer.id !== removeId))
	}

	const editLecturer = (editId, changedLecturer) => {
		setLecturers(
			lecturers.map(
				(lecturer) => (lecturer.id === editId ? changedLecturer : lecturer)
			)
		)
	}

	const showDialog = (lecturerId) => {
		setVisibleDialog(true)
		setEditingLecturer(lecturers.find((lecturer) => lecturer.id === lecturerId))
	}

	const hideDialog = () => {
		setVisibleDialog(false)
		setEditingLecturer(null)
	}

	return (
		<div className="app container">
			<AppHeader lecturers={lecturers} />
			<AppMain
				lecturers={lecturers}
				showDialog={showDialog}
				hideDialog={hideDialog}
				removeLecturer={removeLecturer}
				editLecturer={editLecturer}
			/>
			<LecturerEditDialog
				editLecturer={editLecturer}
				editingLecturer={editingLecturer}
				hideDialog={hideDialog}
				visibleClass={isVisibleDialog ? 'is-active' : ''}
			/>
		</div>
	)
}

export default App
